import json

def get_claim_by_contact_info(email: str = None, phone: str = None) -> str:
    """
    Get claim details by providing either an email or a phone number.
    """
    # In a real application, this would query a database.
    # For this test, we'll return a mock response.
    if email:
        return json.dumps({"status": "success", "message": f"Claim details for {email} retrieved."})
    elif phone:
        return json.dumps({"status": "success", "message": f"Claim details for {phone} retrieved."})
    else:
        return json.dumps({"status": "error", "message": "Either email or phone must be provided."})

def initiate_new_claim(user_id: str, claim_data: dict) -> str:
    """
    Initiate a new claim for a user with the provided claim data.
    """
    # In a real application, this would create a new claim in the database.
    # For this test, we'll return a mock response.
    return json.dumps({"status": "success", "message": f"New claim initiated for user {user_id}."})

def transition_claim_type(claim_id: str, new_claim_type: str) -> str:
    """
    Transition an existing claim to a new type.
    """
    # In a real application, this would update the claim in the database.
    # For this test, we'll return a mock response.
    return json.dumps({"status": "success", "message": f"Claim {claim_id} transitioned to {new_claim_type}."})

def update_claim_data(claim_id: str, updates: dict) -> str:
    """
    Update the data for an existing claim.
    """
    # In a real application, this would update the claim in the database.
    # For this test, we'll return a mock response.
    return json.dumps({"status": "success", "message": f"Claim {claim_id} updated."})
