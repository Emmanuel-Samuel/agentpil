import requests
import json
import time

# The URL of the FastAPI application
URL = "http://127.0.0.1:8000/chat/initial"

# The headers for the request
headers = {
    "Content-Type": "application/json"
}

# The data to be sent in the request
data = {
    "user_id": "test_user_123",
    "message": "I want to get claim details for my account with email test@example.com"
}

def run_test():
    """
    Sends a request to the chat endpoint and prints the response.
    """
    try:
        print(f"Sending request to {URL} with data: {json.dumps(data)}")
        response = requests.post(URL, headers=headers, data=json.dumps(data))
        response.raise_for_status()  # Raise an exception for bad status codes

        print("\n--- Test Results ---")
        print(f"Status Code: {response.status_code}")
        
        response_data = response.json()
        print("Response JSON:")
        print(json.dumps(response_data, indent=2))

        # Give the background task some time to save to Cosmos DB
        print("\nWaiting for 5 seconds for the conversation to be saved to Cosmos DB...")
        time.sleep(5)
        print("Assumed conversation saved to Cosmos DB.")

    except requests.exceptions.RequestException as e:
        print(f"\n--- Test Failed ---")
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    run_test()
